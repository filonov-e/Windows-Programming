﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class MainClass
    {
        static void Main(string[] args)
        {
            Part1.Run();
            Part2.Run();
            return;
        }
    }
}
