﻿namespace Assignment4
{
    class Constants
    {
        public const float TaxForWeekdays = 0.05f;
        public const float TaxForWeekends = 0.07f;
        public const float MaxLuggageWeight = 25.0f;
    }
}
